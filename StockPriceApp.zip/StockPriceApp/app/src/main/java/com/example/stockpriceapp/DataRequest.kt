package com.example.stockpriceapp

import android.os.Parcel
import android.os.Parcelable
import android.widget.Toast
import com.github.kittinunf.fuel.Fuel
import com.github.kittinunf.fuel.httpGet
import com.github.kittinunf.result.Result
import com.squareup.moshi.JsonReader
import com.squareup.moshi.KotlinJsonAdapterFactory
import com.squareup.moshi.Moshi
import kotlinx.coroutines.runBlocking

class RequestIndexData()  {

    var indexData = listOf("")

    fun RequestData(): List<String> {
        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val refreshTokenRequestAdapter = moshi.adapter(Parameter::class.java)
        val header: HashMap<String, String> = hashMapOf("Content-Type" to "application/json")

        val parameter = Parameter(
            mailaddress = "marimocag2@gmail.com",
            password = "princeG21021"
        )

       Fuel.post("https://api.jquants.com/v1/token/auth_user")
            .body(refreshTokenRequestAdapter.toJson(parameter))
            .response { _, response, result ->
                when (result) {
                    is Result.Success -> {

                        val res = response.toString()
                        val jsonAdapter = moshi.adapter(resultRefreshToken::class.java)
                        val data = jsonAdapter.fromJson(res)
                        val idToken = data?.refreshToken

                        Fuel.post("https://api.jquants.com/v1/token/auth_refresh?refreshtoken=$idToken")
                            .response { _, _, result ->
                                when (result) {
                                    is Result.Success -> {
                                        val data2 = result.get()

                                    }
                                    is Result.Failure -> {

                                    }
                                }
                            }
                    }
                    is Result.Failure -> {

                    }
                }
        }
        return indexData
    }
}