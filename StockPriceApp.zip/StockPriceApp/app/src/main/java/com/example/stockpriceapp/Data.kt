package com.example.stockpriceapp

data class Parameter(
    val mailaddress: String,
    val password: String
)

data class resultRefreshToken(
    val refreshToken: String
)

data class requestRefreshToken(
    val refreshtoken: String
)

data class IdToken(
    val idToken: String
)

class RefreshTokenStock {
    lateinit var refreshToken: String
}